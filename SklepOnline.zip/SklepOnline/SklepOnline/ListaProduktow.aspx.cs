﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.ModelBinding;
using SklepOnline.Models;

namespace SklepOnline
{
    public partial class ListaProduktow : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public IQueryable<Produkt> GetProdukty([QueryString("id")] int? kategoriaId)
        {
            var _db = new SklepOnline.Models.ProduktContext();
            IQueryable<Produkt> query = _db.Produkty;
            if(kategoriaId.HasValue && kategoriaId>0)
            {
                query = query.Where(p => p.KategoriaID == kategoriaId);
            }
            return query;
        }
    }
}