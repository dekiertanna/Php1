﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SklepOnline.Models;
using SklepOnline.Logic;
using System.Collections.Specialized;
using System.Collections;
using System.Web.ModelBinding;

namespace SklepOnline
{
    public partial class Koszyk : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (KoszykAkcje uzytkownikKoszyk = new KoszykAkcje())
            {
                decimal koszykTotal =0;
                koszykTotal = uzytkownikKoszyk.GetTotal();
                if(koszykTotal>0)
                {
                    Calosc.Text = String.Format("{0:c}", koszykTotal);
                }
                else
                {
                    CaloscTekst.Text = "";
                    Calosc.Text = "";
                    KoszykTytul.InnerText = "Koszyk jest pusty.";
                    OdswiezBtn.Visible = false;
                    PodsumowanieBtn.Visible = false;
                }
            }
        }

        public List<ProduktKoszyk>GetKoszykProdukty()
        {
            KoszykAkcje akcje = new KoszykAkcje();
            return akcje.GetKoszykPrzedmioty();
        }

        public List<ProduktKoszyk>OdswiezKoszyk()
        {
            using (KoszykAkcje uzytkownikKoszyk = new KoszykAkcje())
            {
                String koszykID = uzytkownikKoszyk.GetKoszykID();

                KoszykAkcje.KoszykZmiany[] koszykZmiany = new KoszykAkcje.KoszykZmiany[KoszykLista.Rows.Count];
                for(int i = 0; i<KoszykLista.Rows.Count; i++)
                {
                    IOrderedDictionary rowVals = new OrderedDictionary();
                    rowVals = GetWartosci(KoszykLista.Rows[i]);
                    koszykZmiany[i].ProduktID = Convert.ToInt32(rowVals["ProduktID"]);

                    CheckBox cbUsun = new CheckBox();
                    cbUsun = (CheckBox)KoszykLista.Rows[i].FindControl("Usun");
                    koszykZmiany[i].UsunPrzedmiot = cbUsun.Checked;

                    TextBox iloscTextBox = new TextBox();
                    iloscTextBox = (TextBox)KoszykLista.Rows[i].FindControl("KupionaIlosc");
                    koszykZmiany[i].ZakupionaIlosc = Convert.ToInt16(iloscTextBox.Text.ToString());

                }
                uzytkownikKoszyk.OdswiezBazeKoszykow(koszykID, koszykZmiany);
                KoszykLista.DataBind();
                Calosc.Text = String.Format("{0:c}", uzytkownikKoszyk.GetTotal());
                return uzytkownikKoszyk.GetKoszykPrzedmioty();
            }
        }

        public static IOrderedDictionary GetWartosci(GridViewRow row)
        {
            IOrderedDictionary wartosci = new OrderedDictionary();
            foreach (DataControlFieldCell cell in row.Cells)
            {
                if(cell.Visible)
                {
                    cell.ContainingField.ExtractValuesFromCell(wartosci, cell, row.RowState, true);
                }
            }
            return wartosci;
        }

        protected void OdswiezBtn_Click(object sender, EventArgs e)
        {
            OdswiezKoszyk();
        }

        protected void PodsumowanieBtn_Click(object sender, ImageClickEventArgs e)
        {
            using (KoszykAkcje koszykUzytkownik = new KoszykAkcje())
            {
                Session["payment_amt"] = koszykUzytkownik.GetTotal();
            }
            Response.Redirect("Podsumowanie/PodsumowanieStart.aspx");
        }
    }
}