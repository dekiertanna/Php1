﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SklepOnline.Models
{
    public class SzczegolyZamowienia
    {
        public int SzczegolyZamowieniaID { get; set; }

        public int ZamowienieID { get; set; }

        public string NazwaUzytkownika { get; set; }

        public int ProduktID { get; set; }

        public int Ilosc { get; set; }

        public double? CenaJednostkowa { get; set; }
    }
}