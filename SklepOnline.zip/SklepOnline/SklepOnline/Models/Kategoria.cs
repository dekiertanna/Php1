﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SklepOnline.Models
{
    public class Kategoria
    {
        [ScaffoldColumn(false)]
        public int KategoriaID { get; set; }

        [Required, StringLength(100), Display(Name = "Nazwa")]
        public string NazwaKategorii { get; set; }

        [Display(Name = "Opis produktu")]
        public String Opis { get; set; }

        public virtual ICollection<Produkt> Produkty { get; set; }
    }
}