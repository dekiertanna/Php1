﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace SklepOnline.Models
{
    public class DbInitializer : DropCreateDatabaseIfModelChanges<ProduktContext>
    {
        protected override void Seed(ProduktContext context)
        {
            GetKategorie().ForEach(c => context.Kategorie.Add(c));
            GetProdukty().ForEach(p => context.Produkty.Add(p));
        }

        private static List<Kategoria> GetKategorie()
        {
            var kategorie = new List<Kategoria>
            {
                new Kategoria
                {
                    KategoriaID = 1,
                    NazwaKategorii = "Motocykle"
                },

                new Kategoria
                {
                    KategoriaID = 2,
                    NazwaKategorii = "Ciężarówki"
                },

                new Kategoria
                {
                    KategoriaID = 3,
                    NazwaKategorii = "Cabrio"
                },

                new Kategoria
                {
                    KategoriaID = 4,
                    NazwaKategorii = "Samochody osobowe"
                },

                new Kategoria
                {
                    KategoriaID = 5,
                    NazwaKategorii = "Samochody wyścigowe"
                }
            };

            return kategorie;
        }

        private static List<Produkt> GetProdukty()
        {
            var produkty = new List<Produkt>
            {
                new Produkt
                {
                    ProduktID = 1,
                    NazwaProduktu = "Ducati Desmosedici GP13",
                    Opis = "MARKA :	Ducati MODEL: Ducati Desmosedici GP13 PRODUCENT : Minichamps SKALA:	1:12 MATERIAŁ: Plastik",
                    SciezkaObrazu ="Ducati Desmosedici GP13.jpg",
                    CenaJednostkowa = 479.00,
                    KategoriaID = 1
                },

                new Produkt
                {
                    ProduktID = 2,
                    NazwaProduktu = "Honda RC213V",
                    Opis = "MARKA: Honda MODEL:Honda RC213V PRODUCENT: Minichamps SKALA: 1:12 MATERIAŁ: Metal/Plastik",
                    SciezkaObrazu ="Honda RC213V.jpg",
                    CenaJednostkowa = 475.00,
                    KategoriaID = 1
                },

                new Produkt
                {
                    ProduktID = 3,
                    NazwaProduktu = "Harley Davidson FL Hydra Glide",
                    Opis = "MARKA: Harley-Davidson MODEL:Harley Davidson FL Hydra Glide PRODUCENT: Maisto SKALA: 1:18 MATERIAŁ: Metal/Plastik",
                    SciezkaObrazu ="Harley Davidson FL Hydra Glide.jpg",
                    CenaJednostkowa = 72.00,
                    KategoriaID = 1
                },

                new Produkt
                {
                    ProduktID = 4,
                    NazwaProduktu = "Mercedes LS 1620",
                    Opis = "MARKA: Mercedes MODEL: Mercedes LS 1620 PRODUCENT: Brekina SKALA: 1:87 MATERIAŁ: Plastik",
                    SciezkaObrazu ="Mercedes LS 1620.jpg",
                    CenaJednostkowa = 172.00,
                    KategoriaID = 2
                },

                new Produkt
                {
                    ProduktID = 5,
                    NazwaProduktu = "MAN 10.212 F Grosraumaufbau mt Nilpferd",
                    Opis = "MARKA: MAN MODEL: MAN 10.212 F Grosraumaufbau mt Nilpferd PRODUCENT: Brekina SKALA: 1:87 MATERIAŁ: Plastik",
                    SciezkaObrazu ="MAN 10212 F Grosraumaufbau mt Nilpferd.jpg",
                    CenaJednostkowa = 134.00,
                    KategoriaID = 2
                },

                new Produkt
                {
                    ProduktID = 6,
                    NazwaProduktu = "Mercedes Actros Giga. SLT",
                    Opis = "MARKA: Mercedes MODEL: Mercedes Actros Giga. SLT PRODUCENT: Herpa SKALA: 1:87 MATERIAŁ: Plastik",
                    SciezkaObrazu ="Mercedes Actros Giga SLT.jpg",
                    CenaJednostkowa = 86.00,
                    KategoriaID = 2
                },

                new Produkt
                {
                    ProduktID = 7,
                    NazwaProduktu = "Mercury Turnpike Cruiser Convertible",
                    Opis = "MARKA: Mercury MODEL: Mercury Turnpike Cruiser Convertible PRODUCENT: Neo SKALA: 1:43 MATERIAŁ: Żywica",
                    SciezkaObrazu ="Mercury Turnpike Cruiser Convertible.jpg",
                    CenaJednostkowa = 359.00,
                    KategoriaID = 3
                },

                new Produkt
                {
                    ProduktID = 8,
                    NazwaProduktu = "Saab 900 Turbo 16 Cabriolet",
                    Opis = "MARKA: Saab MODEL: Saab 900 Turbo 16 Cabriolet PRODUCENT: Norev SKALA: 1:43 MATERIAŁ: Metal/Plastik",
                    SciezkaObrazu ="Saab 900 Turbo 16 Cabriolet.jpg",
                    CenaJednostkowa = 167.00,
                    KategoriaID = 3
                },

                 new Produkt
                {
                    ProduktID = 9,
                    NazwaProduktu = "Maserati 3500 GT Spyder by Frua",
                    Opis = "MARKA: Maserati MODEL: Maserati 3500 GT Spyder by Frua PRODUCENT: Matrix SKALA: 1:43 MATERIAŁ: Żywica",
                    SciezkaObrazu ="Maserati 3500 GT Spyder by Frua.jpg",
                    CenaJednostkowa = 407.00,
                    KategoriaID = 3
                },

                 new Produkt
                {
                    ProduktID = 10,
                    NazwaProduktu = "Jaguar F-Type R Coupe",
                    Opis = "MARKA: Jaguar MODEL: Jaguar F-Type R Coupe PRODUCENT: Top Speed SKALA: 1:18 MATERIAŁ: Żywica",
                    SciezkaObrazu ="Jaguar F-Type R Coupe.jpg",
                    CenaJednostkowa = 671.00,
                    KategoriaID = 4
                },

                 new Produkt
                {
                    ProduktID = 11,
                    NazwaProduktu = "Ford Focus Stufenheck",
                    Opis = "MARKA: Ford MODEL: Ford Focus Stufenheck PRODUCENT: I-Rietze SKALA: 1:87 MATERIAŁ: Plastik",
                    SciezkaObrazu ="Ford Focus Stufenheck.jpg",
                    CenaJednostkowa = 33.00,
                    KategoriaID = 4
                },

                 new Produkt
                {
                    ProduktID = 12,
                    NazwaProduktu = "Mercedes W124 300E 5.6 AMG",
                    Opis = "MARKA: Mercedes MODEL: Mercedes W124 300E 5.6 AMG PRODUCENT: Ottomobile SKALA: 1:18 MATERIAŁ: Żywica",
                    SciezkaObrazu ="Mercedes W124 300E 56 AMG.jpg",
                    CenaJednostkowa = 407.00,
                    KategoriaID = 4
                },

                 new Produkt
                {
                    ProduktID = 13,
                    NazwaProduktu = "Audi R8 LMS",
                    Opis = "MARKA: Audi MODEL: Audi R8 LMS PRODUCENT: Minichamps SKALA: 1:43 MATERIAŁ: Żywica",
                    SciezkaObrazu ="Audi R8 LMS.jpg",
                    CenaJednostkowa = 459.00,
                    KategoriaID = 5
                },

                 new Produkt
                {
                    ProduktID = 14,
                    NazwaProduktu = "Williams Renault FW16",
                    Opis = "MARKA: Williams MODEL: Williams Renault FW16 PRODUCENT: Minichamps SKALA: 1:43 MATERIAŁ: Żywica",
                    SciezkaObrazu ="Williams Renault FW16.jpg",
                    CenaJednostkowa = 383.00,
                    KategoriaID = 5
                },

                  new Produkt
                {
                    ProduktID = 15,
                    NazwaProduktu = "Bentley GT3",
                    Opis = "MARKA: Bentley MODEL: Bentley GT3 PRODUCENT: TrueScale Miniatures SKALA: 1:18 MATERIAŁ: Żywica",
                    SciezkaObrazu ="Bentley GT3.jpg",
                    CenaJednostkowa = 1054.00,
                    KategoriaID = 5
                }


            };
            return produkty;
        }
    }
}