﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace SklepOnline.Models
{
    public class Zamowienie
    {
        public int ZamowienieId { get; set; }
        public System.DateTime DataZamowienia { get; set; }
        public string NazwaUzytkownika { get; set; }

        //[Required(ErrorMessage = "To pole jest obowiązkowe")]
        [DisplayName("Imię")]
        [StringLength(160)]
        public string Imie { get; set; }

       // [Required(ErrorMessage = "To pole jest obowiązkowe")]
        [DisplayName("Nazwisko")]
        [StringLength(160)]
        public string Nazwisko { get; set; }

      //  [Required(ErrorMessage = "To pole jest obowiązkowe")]
        [StringLength(70)]
        public string Adres { get; set; }

       // [Required(ErrorMessage = "To pole jest obowiązkowe")]
        [StringLength(40)]
        public string Miasto { get; set; }

        //[Required(ErrorMessage = "To pole jest obowiązkowe")]
        [StringLength(40)]
        public string wojewodztwo { get; set; }

        //[Required(ErrorMessage = "To pole jest obowiązkowe")]
        [DisplayName("Kod pocztowy")]
        [StringLength(10)]
        public string PostalCode { get; set; }

       // [Required(ErrorMessage = "To pole jest obowiązkowe")]
        [StringLength(40)]
        public string Kraj { get; set; }

        [StringLength(24)]
        public string Telefon { get; set; }

        //[Required(ErrorMessage = "To pole jest obowiązkowe")]
        [DisplayName("Adres e-mail")]
        [RegularExpression(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}",
        ErrorMessage = "Niepoprawny e-mail")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [ScaffoldColumn(false)]
        public Decimal Total { get; set; }

        [ScaffoldColumn(false)]
        public string TransakcjaID { get; set; }

        [ScaffoldColumn(false)]
        public bool Dostarczono { get; set; }

        public List<SzczegolyZamowienia> SzczegolyZamowienia { get; set; }
    }
}