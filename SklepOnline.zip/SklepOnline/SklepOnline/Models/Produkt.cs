﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SklepOnline.Models
{
    public class Produkt
    {
        [ScaffoldColumn(false)]
        public int ProduktID { get; set; }

        [Required, StringLength(100), Display(Name = "Nazwa")]
        public string NazwaProduktu { get; set; }

        [Required, StringLength(1000), Display(Name = "Opis produktu"), DataType(DataType.MultilineText)]
        public string Opis { get; set; }

        public string SciezkaObrazu { get; set; }

        [Display(Name = "Cena")]
        public double? CenaJednostkowa { get; set; }

        public int? KategoriaID { get; set; }

        public virtual Kategoria Kategoria { get; set; }
    }
}