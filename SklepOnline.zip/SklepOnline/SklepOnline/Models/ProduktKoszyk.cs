﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SklepOnline.Models
{
    public class ProduktKoszyk
    {
        [Key]
        public string PrzedmiotID { get; set; }

        public string KoszykID { get; set; }

        public int Ilosc { get; set; }

        public System.DateTime DataUtworzenia { get; set; }

        public int ProduktID { get; set;}

        public virtual Produkt Produkt { get; set; }
    }
}