﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SklepOnline.Models;

namespace SklepOnline.Logic
{
    public class KoszykAkcje : IDisposable
    {
        public string KoszykID { get; set; }

        private ProduktContext _db = new ProduktContext();

        public const string KoszykSesjaKlucz = "KoszykID";

        public void DodajDoKoszyka(int id)
        {
            KoszykID = GetKoszykID();

            var koszykPrzedmiot = _db.ProduktyKoszyk.SingleOrDefault(
                c => c.KoszykID == KoszykID
                && c.ProduktID == id);

            if(koszykPrzedmiot == null)
            {
                koszykPrzedmiot = new ProduktKoszyk
                {
                    PrzedmiotID = Guid.NewGuid().ToString(),
                    ProduktID = id,
                    KoszykID = KoszykID,
                    Produkt = _db.Produkty.SingleOrDefault(p => p.ProduktID == id),
                    Ilosc = 1,
                    DataUtworzenia = DateTime.Now
                };

                _db.ProduktyKoszyk.Add(koszykPrzedmiot);
            }
            else
            {
                koszykPrzedmiot.Ilosc++;
            }
            _db.SaveChanges();
        }

        public void Dispose()
        {
           if(_db!=null)
            {
                _db.Dispose();
                _db = null;
            }
        }

        public string GetKoszykID()
        {
            if(HttpContext.Current.Session[KoszykSesjaKlucz] == null)
            {
                if(!string.IsNullOrWhiteSpace(HttpContext.Current.User.Identity.Name))
                {
                    HttpContext.Current.Session[KoszykSesjaKlucz] = HttpContext.Current.User.Identity.Name;
                }
                else
                {
                    Guid tempKoszykID = Guid.NewGuid();
                    HttpContext.Current.Session[KoszykSesjaKlucz] = tempKoszykID.ToString();
                }
            }
            return HttpContext.Current.Session[KoszykSesjaKlucz].ToString();
        }

        public List<ProduktKoszyk>GetKoszykPrzedmioty()
        {
            KoszykID = GetKoszykID();
            return _db.ProduktyKoszyk.Where(c => c.KoszykID == KoszykID).ToList();
        }

        public decimal GetTotal()
        {
            KoszykID = GetKoszykID();
            decimal? total = decimal.Zero;
            total = (decimal?)(from produktyKoszyk in _db.ProduktyKoszyk
                               where produktyKoszyk.KoszykID == KoszykID
                               select (int?)produktyKoszyk.Ilosc * produktyKoszyk.Produkt.CenaJednostkowa).Sum();
            return total ?? decimal.Zero;
        }

        public KoszykAkcje GetKoszyk(HttpContext kontekst)
        {
            using (var koszyk = new KoszykAkcje())
            {
                koszyk.KoszykID = koszyk.GetKoszykID();
                return koszyk;
            }
        }

        public void OdswiezBazeKoszykow(String koszykID, KoszykZmiany[] OdswiezPrzedmiotKoszyk)
        {
            using (var db = new SklepOnline.Models.ProduktContext())
            {
                try
                {
                    int KoszykLiczbaProduktow = OdswiezPrzedmiotKoszyk.Count();
                    List<ProduktKoszyk> mojKoszyk = GetKoszykPrzedmioty();
                    foreach(var koszykProdukt in mojKoszyk)
                    {
                        for (int i = 0; i< KoszykLiczbaProduktow;i++)
                        {
                            if(koszykProdukt.Produkt.ProduktID == OdswiezPrzedmiotKoszyk[i].ProduktID)
                            {
                                if (OdswiezPrzedmiotKoszyk[i].ZakupionaIlosc < 1 || OdswiezPrzedmiotKoszyk[i].UsunPrzedmiot == true)
                                {
                                    UsunPrzedmiot(koszykID, koszykProdukt.ProduktID);
                                }
                                else
                                {
                                    OdswiezPrzedmiot(koszykID, koszykProdukt.ProduktID, OdswiezPrzedmiotKoszyk[i].ZakupionaIlosc);
                                }
                            }
                        }
                    }
                }
                catch(Exception ex)
                {
                    throw new Exception("Nie mozna zmienic bazy koszykow - " + ex.Message.ToString(), ex);
                }
            }
        }

        public void UsunPrzedmiot(string usunKoszykID, int usunProduktID)
        {
            using (var _db = new SklepOnline.Models.ProduktContext())
            {
                try
                {
                    var mojPrzedmiot = (from c in _db.ProduktyKoszyk where c.KoszykID == usunKoszykID && c.Produkt.ProduktID == usunProduktID select c).FirstOrDefault();
                    if(mojPrzedmiot!=null)
                    {
                        _db.ProduktyKoszyk.Remove(mojPrzedmiot);
                        _db.SaveChanges();
                    }
                }
                catch(Exception ex)
                {
                    throw new Exception("Nie mozna usunac przedmiotu z koszyka - " + ex.Message.ToString(), ex);
                }
            }
        }

        public void OdswiezPrzedmiot(string odswiezKoszykID, int odswiezProduktID, int ilosc)
        {
            using (var _db = new SklepOnline.Models.ProduktContext())
            {
                try
                {
                    var mojPrzedmiot = (from c in _db.ProduktyKoszyk where c.KoszykID == odswiezKoszykID && c.ProduktID == odswiezProduktID select c).FirstOrDefault();
                    if(mojPrzedmiot!=null)
                    {
                        mojPrzedmiot.Ilosc = ilosc;
                        _db.SaveChanges();
                    }
                }
                catch(Exception ex)
                {
                    throw new Exception("Nie mozna zmienic ilosci przedmiotow w kosztku - " + ex.Message.ToString());
                }
            }
        }

        public void OproznijKoszyk()
        {
            KoszykID = GetKoszykID();
            var koszykPrzedmioty = _db.ProduktyKoszyk.Where(
                c => c.KoszykID == KoszykID);
            foreach(var koszykPrzedmiot in koszykPrzedmioty)
            {
                _db.ProduktyKoszyk.Remove(koszykPrzedmiot);
            }
            _db.SaveChanges();
        }

        public int GetIlosc()
        {
            KoszykID = GetKoszykID();

            int? ilosc = (from koszykPrzedmioty in _db.ProduktyKoszyk
                          where koszykPrzedmioty.KoszykID == KoszykID
                          select (int?)koszykPrzedmioty.Ilosc).Sum();
            return ilosc ?? 0;
        }

        public struct KoszykZmiany
        {
            public int ProduktID;
            public int ZakupionaIlosc;
            public bool UsunPrzedmiot;
        }

        public void PrzeniesKoszyk(string koszykID, string nazwaUzytkownika)
        {
            var koszyk = _db.ProduktyKoszyk.Where(c => c.KoszykID == koszykID);
            foreach(ProduktKoszyk produkt in koszyk)
            {
                produkt.KoszykID = nazwaUzytkownika;
            }
            HttpContext.Current.Session[KoszykSesjaKlucz] = nazwaUzytkownika;
            _db.SaveChanges();
        }
    }

}