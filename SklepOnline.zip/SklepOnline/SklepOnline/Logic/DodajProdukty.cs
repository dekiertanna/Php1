﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SklepOnline.Models;

namespace SklepOnline.Logic
{
    public class DodajProdukty
    {
        public bool DodajProdukt(string NazwaProduktu, string OpisProduktu, string cenaProduktu, string KategoriaProduktu, string SciezkaObrazuProduktu)
        {
            var mojProdukt = new Produkt();
            mojProdukt.NazwaProduktu = NazwaProduktu;
            mojProdukt.Opis = OpisProduktu;
            mojProdukt.CenaJednostkowa = Convert.ToDouble(cenaProduktu);
            mojProdukt.SciezkaObrazu = SciezkaObrazuProduktu;
            mojProdukt.KategoriaID = Convert.ToInt32(KategoriaProduktu);

            using (ProduktContext _db = new ProduktContext())
            {
                _db.Produkty.Add(mojProdukt);
                _db.SaveChanges();
            }
            return true;
        }
    }
}