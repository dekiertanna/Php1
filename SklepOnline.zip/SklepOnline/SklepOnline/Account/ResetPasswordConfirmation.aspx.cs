﻿using System.Web.UI;

namespace SklepOnline.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}