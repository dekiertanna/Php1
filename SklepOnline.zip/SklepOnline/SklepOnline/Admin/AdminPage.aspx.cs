﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SklepOnline.Models;
using SklepOnline.Logic;

namespace SklepOnline.Admin
{
    public partial class AdminPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string produktAkcja = Request.QueryString["ProduktAkcja"];
            if(produktAkcja=="dodaj")
            {
                LabelDodajStatus.Text = "Dodano produkt";
            }
            if(produktAkcja=="usun")
            {
                LabelUsunStatus.Text = "Usunięto produkt";
            }
        }

        protected void DodajProduktButton_Click(object sender, EventArgs e)
        {
            Boolean fileOK = false;
            String path = Server.MapPath("~/Catalog/Images/");
            if(ObrazProduktu.HasFile)
            {
                String fileExtension = System.IO.Path.GetExtension(ObrazProduktu.FileName).ToLower();
                String[] allowedExtensions = { ".gif", ".png", ".jpeg", ".jpg" };
                for(int i = 0; i<allowedExtensions.Length;i ++)
                {
                    if(fileExtension == allowedExtensions[i])
                    {
                        fileOK = true;
                    }
                }
            }
            if(fileOK)
            {
                try
                {
                    ObrazProduktu.PostedFile.SaveAs(path + ObrazProduktu.FileName);
                    ObrazProduktu.PostedFile.SaveAs(path + "/Thumbs/" + ObrazProduktu.FileName);
                }
                catch(Exception ex)
                {
                    LabelDodajStatus.Text = ex.Message;
                }

                DodajProdukty produkty = new DodajProdukty();
                bool dodajSukces = produkty.DodajProdukt(DodajNazweProduktu.Text, DodajOpisProduktu.Text, DodajCeneProduktu.Text, DropDownDodajKategorie.SelectedValue, ObrazProduktu.FileName);
                if(dodajSukces)
                {
                    string pageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.Count() - Request.Url.Query.Count());
                    Response.Redirect(pageUrl + "?ProduktAkcja=dodaj");

                }
                else
                {
                    LabelDodajStatus.Text = "Nie można dodać produktu";
                }
            }
            else
            {
                LabelDodajStatus.Text = "Nie można użyć pliku";
            }
        }
        public IQueryable GetKategorie()
        {
            var _db = new SklepOnline.Models.ProduktContext();
            IQueryable query = _db.Kategorie;
            return query;
        }

        public IQueryable GetProdukty()
        {
            var _db = new SklepOnline.Models.ProduktContext();
            IQueryable query = _db.Produkty;
            return query;
        }

        protected void UsunProduktButton_Click(object sender, EventArgs e)
        {
            using (var _db = new SklepOnline.Models.ProduktContext())
            {
                int produktID = Convert.ToInt16(DropDownUsunProdukt.SelectedValue);
                var mojPrzedmiot = (from c in _db.Produkty where c.ProduktID == produktID select c).FirstOrDefault();
                if(mojPrzedmiot !=null)
                {
                    _db.Produkty.Remove(mojPrzedmiot);
                    _db.SaveChanges();
                    string pageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.Count() - Request.Url.Query.Count());
                    Response.Redirect(pageUrl + "?ProduktAkcja=usun");
                }
                else
                {
                    LabelUsunStatus.Text = "Nie mozna znaleźć produktu";
                }
            }
        }


    }
}