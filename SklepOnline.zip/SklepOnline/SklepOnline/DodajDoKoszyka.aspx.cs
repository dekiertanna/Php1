﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SklepOnline.Logic;
using System.Diagnostics;

namespace SklepOnline
{
    public partial class DodajDoKoszyka : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string rawID = Request.QueryString["ProduktID"];
            int produktID;
            if(!String.IsNullOrEmpty(rawID) && int.TryParse(rawID, out produktID))
            {
                using (KoszykAkcje uzytkownikKoszyk = new KoszykAkcje())
                {
                    uzytkownikKoszyk.DodajDoKoszyka(Convert.ToInt16(rawID));
                }
            }
            else
            {
                Debug.Fail("Błąd: Nie mozna uzyskac dostepu do DodajDoKoszyka.aspx bez ProduktID");
                throw new Exception("Blad: Nie mozna zaladowac DodajDoKoszyka.aspx bez ustalenia ProduktID");
            }
            Response.Redirect("Koszyk.aspx");

        }
    }
}