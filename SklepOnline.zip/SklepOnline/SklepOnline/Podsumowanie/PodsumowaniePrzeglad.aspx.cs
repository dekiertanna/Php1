﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SklepOnline.Models;
using System.Data.Entity.Validation;

namespace SklepOnline.Podsumowanie
{
    public partial class PodsumowaniePrzeglad : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                NVPAPICaller payPalCaller = new NVPAPICaller();

                string retMsg = "";
                string token = "";
                string PayerID = "";
                NVPCodec decoder = new NVPCodec();
                token = Session["token"].ToString();

                bool ret = payPalCaller.GetCheckoutDetails(token, ref PayerID, ref decoder, ref retMsg);
                if (ret)
                {
                    Session["payerId"] = PayerID;

                    var mojeZamowienie = new Zamowienie();
                    mojeZamowienie.DataZamowienia = Convert.ToDateTime(decoder["TIMESTAMP"].ToString());
                    mojeZamowienie.NazwaUzytkownika = User.Identity.Name;
                    mojeZamowienie.Imie = decoder["FIRSTNAME"].ToString();
                    mojeZamowienie.Nazwisko = decoder["LASTNAME"].ToString();
                    mojeZamowienie.Adres = decoder["SHIPTOSTREET"].ToString();
                    mojeZamowienie.Miasto = decoder["SHIPTOCITY"].ToString();
                    try
                    {
                        mojeZamowienie.wojewodztwo = decoder["SHIPTOSTATE"].ToString();
                    }
                    catch(NullReferenceException ex)
                    {
                        mojeZamowienie.wojewodztwo = "";
                    }
                    mojeZamowienie.PostalCode = decoder["SHIPTOZIP"].ToString();
                    mojeZamowienie.Kraj = decoder["SHIPTOCOUNTRYCODE"].ToString();
                    mojeZamowienie.Email = decoder["EMAIL"].ToString();
                    try
                    {
                        mojeZamowienie.Total = Convert.ToDecimal(Session["payment_amt"].ToString());
                    }
                    catch(FormatException exc)
                    {
                        Console.WriteLine(decoder["AMT"]);
                    }

                    // Verify total payment amount as set on CheckoutStart.aspx.
                    try
                    {
                        Decimal paymentAmountOnCheckout = Convert.ToDecimal(Session["payment_amt"].ToString());
                        Decimal paymentAmoutFromPayPal = Convert.ToDecimal(Session["payment_amt"].ToString());
                        if (paymentAmountOnCheckout != paymentAmoutFromPayPal)
                        {
                            Response.Redirect("PodsumowanieBlad.aspx?" + "Desc=Amount%20total%20mismatch.");
                        }
                    }
                    catch (Exception)
                    {
                        Response.Redirect("PodsumowanieBlad.aspx?" + "Desc=Amount%20total%20mismatch.");
                    }
                    
                    // Get DB context.
                    ProduktContext _db = new ProduktContext();

                    // Add order to DB.
                    try
                    {
                        _db.Zamowienia.Add(mojeZamowienie);
                        _db.SaveChanges();
                    }
                    catch (DbEntityValidationException exx)
                    {
                        foreach (var eve in exx.EntityValidationErrors)
                        {
                            System.Diagnostics.Trace.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:"+
                                eve.Entry.Entity.GetType().Name+ eve.Entry.State);
                            foreach (var ve in eve.ValidationErrors)
                            {
                                 System.Diagnostics.Trace.WriteLine("- Property: \"{0}\", Error: \"{1}\""+
                                    ve.PropertyName+ ve.ErrorMessage);
                            }
                        }
                       
                    }
                    // Get the shopping cart items and process them.
                    using (SklepOnline.Logic.KoszykAkcje koszykUzytkownik = new SklepOnline.Logic.KoszykAkcje())
                    {
                        List<ProduktKoszyk> myOrderList = koszykUzytkownik.GetKoszykPrzedmioty();

                        // Add OrderDetail information to the DB for each product purchased.
                        for (int i = 0; i < myOrderList.Count; i++)
                        {
                            // Create a new OrderDetail object.
                            var myOrderDetail = new SzczegolyZamowienia();
                            myOrderDetail.ZamowienieID = mojeZamowienie.ZamowienieId;
                            myOrderDetail.NazwaUzytkownika = User.Identity.Name;
                            myOrderDetail.ProduktID = myOrderList[i].ProduktID;
                            myOrderDetail.Ilosc = myOrderList[i].Ilosc;
                            myOrderDetail.CenaJednostkowa = myOrderList[i].Produkt.CenaJednostkowa;

                            // Add OrderDetail to DB.
                            _db.SzczegolyZamowien.Add(myOrderDetail);
                            _db.SaveChanges();
                        }

                        // Set OrderId.
                        Session["currentOrderId"] = mojeZamowienie.ZamowienieId;

                        // Display Order information.
                        List<Zamowienie> orderList = new List<Zamowienie>();
                        orderList.Add(mojeZamowienie);
                        DostawaInfo.DataSource = orderList;
                        DostawaInfo.DataBind();

                        // Display OrderDetails.
                        ListaZamowien.DataSource = myOrderList;
                        ListaZamowien.DataBind();
                    }
                }
                else
                {
                    Response.Redirect("CheckoutError.aspx?" + retMsg);
                }
            }

        }

        protected void PotwierdzZamowienie_Click(object sender, EventArgs e)
        {
            Session["userCheckoutCompleted"] = "true";
            Response.Redirect("~/Podsumowanie/PodsumowanieGotowe.aspx");
        }
    }
}